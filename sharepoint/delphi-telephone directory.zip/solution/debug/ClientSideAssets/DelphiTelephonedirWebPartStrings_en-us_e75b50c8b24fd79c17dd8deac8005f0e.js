define([], function () {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "SearchUser": "Search User by First Name",
    "SearchUserByFirstName": "Search User by First Name",
    "SearchUserByLastName": "Search User by Last Name",
    "DisplayName": "Name",
    "Email": "Email",
    "MobilePhone": "Mobile Phone",
    "JobTitle": "Job Title",
    "OfficeLocation": "Office Location",
    "businessPhone": "Business Phone",
    "WebpartTitle": "Telephone Directory",
    "Title": "Title"
  }
});